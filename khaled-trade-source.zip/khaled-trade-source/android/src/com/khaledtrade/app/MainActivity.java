package com.khaledtrade.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/* تطبيق خالد تريد للأندرويد: غلاف WebView بيفتح برنامج الحسابات من رابطه الرسمي.
   كل البيانات والمنطق في الموقع نفسه (بيتحدث تلقائي). الغلاف بس بيظبط: رسائل التأكيد، رفع الملفات،
   الكاميرا (الباركود)، تنزيل الملفات (PDF والنسخة الاحتياطية)، الطباعة، زر الرجوع، والروابط الخارجية (واتساب). */
public class MainActivity extends Activity {
    static final String HOST = "civilm7mmd.github.io";
    static final String URL = "https://civilm7mmd.github.io/khaled-trade-app/";
    WebView wv;
    ValueCallback<Uri[]> fileCb;
    PermissionRequest pendingPerm;
    long lastBack = 0;
    String pendName, pendMime, pendB64;

    static final String HOOK =
        "(function(){if(window.__ktA)return;window.__ktA=1;"
        + "function send(h,n){fetch(h).then(function(r){return r.blob()}).then(function(b){var f=new FileReader();f.onload=function(){AndroidBridge.save(n||'file',b.type||'application/octet-stream',String(f.result).split(',')[1]||'')};f.readAsDataURL(b)})}"
        + "var oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){if(this.hasAttribute('download')&&/^(blob|data):/.test(this.href)){send(this.href,this.getAttribute('download'));return}return oc.apply(this,arguments)};"
        + "document.addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[download]');if(a&&/^(blob|data):/.test(a.href)){e.preventDefault();send(a.href,a.getAttribute('download'))}},true);"
        + "window.open=function(u){if(u&&/^(blob|data):/.test(u)){send(u,'document')}else if(u){AndroidBridge.ext(String(u))}return null};"
        + "window.print=function(){AndroidBridge.print()}})();";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#13233B"));
        getWindow().setNavigationBarColor(Color.parseColor("#13233B"));
        wv = new WebView(this);
        wv.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " KhaledTradeApp/1");
        WebView.setWebContentsDebuggingEnabled(false);
        wv.addJavascriptInterface(new Bridge(), "AndroidBridge");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme() == null ? "" : u.getScheme();
                if ((sc.equals("https") || sc.equals("http")) && HOST.equals(u.getHost())) return false;
                openExternal(u);
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(HOOK, null);
            }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String h = "<html dir='rtl'><body style='font-family:sans-serif;background:#13233b;color:#fff;text-align:center;padding:40px 20px'>"
                        + "<h2>مفيش اتصال بالإنترنت</h2><p>اتأكد من النت وجرب تاني.</p>"
                        + "<button style='font-size:18px;padding:12px 28px;border:0;border-radius:10px;background:#2e7d5b;color:#fff' onclick=\"location.href='" + URL + "'\">إعادة المحاولة</button></body></html>";
                    v.loadDataWithBaseURL(URL, h, "text/html", "utf-8", null);
                }
            }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("تمام", (d, w) -> r.confirm()).show();
                return true;
            }
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setCancelable(false)
                    .setPositiveButton("تمام", (d, w) -> r.confirm())
                    .setNegativeButton("إلغاء", (d, w) -> r.cancel()).show();
                return true;
            }
            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this);
                et.setText(def == null ? "" : def);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et).setCancelable(false)
                    .setPositiveButton("تمام", (d, w) -> r.confirm(et.getText().toString()))
                    .setNegativeButton("إلغاء", (d, w) -> r.cancel()).show();
                return true;
            }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), 77);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean cam = false;
                    for (String x : req.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x)) cam = true;
                    if (!cam) { req.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                    } else {
                        pendingPerm = req;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, 78);
                    }
                });
            }
        });
        if (b != null) wv.restoreState(b); else wv.loadUrl(URL);
    }

    void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "مفيش تطبيق يفتح الرابط ده", Toast.LENGTH_SHORT).show();
        }
    }

    class Bridge {
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                pm.print("خالد تريد", wv.createPrintDocumentAdapter("khaled-trade"), new PrintAttributes.Builder().build());
            });
        }
        @JavascriptInterface
        public void ext(final String u) {
            runOnUiThread(() -> { try { openExternal(Uri.parse(u)); } catch (Exception e) { } });
        }
        @JavascriptInterface
        public void save(final String name, final String mime, final String b64) {
            runOnUiThread(() -> saveFile(name, mime, b64));
        }
    }

    String safeName(String n, String mime) {
        String x = (n == null ? "file" : n).replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!x.contains(".")) {
            if (mime.contains("pdf")) x += ".pdf";
            else if (mime.contains("png")) x += ".png";
            else if (mime.contains("jpeg")) x += ".jpg";
            else if (mime.contains("json")) x += ".json";
            else x += ".bin";
        }
        return x;
    }

    void saveFile(String name, String mime, String b64) {
        String fn = safeName(name, mime);
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, fn);
                cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(data);
                os.close();
                Toast.makeText(this, "اتحفظ في التنزيلات: " + fn, Toast.LENGTH_LONG).show();
                if (mime.contains("pdf") || mime.startsWith("image/")) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) { }
                }
            } else {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    pendName = name; pendMime = mime; pendB64 = b64;
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 79);
                    return;
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                dir.mkdirs();
                FileOutputStream fo = new FileOutputStream(new File(dir, fn));
                fo.write(data);
                fo.close();
                Toast.makeText(this, "اتحفظ في التنزيلات: " + fn, Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (code == 78 && pendingPerm != null) {
            if (ok) pendingPerm.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE}); else pendingPerm.deny();
            pendingPerm = null;
        } else if (code == 79 && ok && pendB64 != null) {
            saveFile(pendName, pendMime, pendB64);
            pendB64 = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 77 && fileCb != null) {
            fileCb.onReceiveValue(res == RESULT_OK && data != null ? WebChromeClient.FileChooserParams.parseResult(res, data) : null);
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (wv.canGoBack()) { wv.goBack(); return; }
        long n = System.currentTimeMillis();
        if (n - lastBack < 2000) { super.onBackPressed(); return; }
        lastBack = n;
        Toast.makeText(this, "دوس رجوع تاني للخروج", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); wv.saveState(b); }
    @Override protected void onPause() { super.onPause(); wv.onPause(); }
    @Override protected void onResume() { super.onResume(); wv.onResume(); }
}
