set -e
export KSP=$(cat /downloads/kt/apk/.kspass)  # كلمة سر مفتاح التوقيع عند المالك بس
cd /downloads/kt/apk/proj
SDK=/downloads/kt/apk/sdk; BT=$SDK/android-14; AJ=$SDK/android-34/android.jar
export PATH=$SDK/jdk-17.0.21.1+2/bin:$BT:$PATH
rm -rf out && mkdir -p out/flat out/cls out/dex
aapt2 compile --dir res -o out/flat
aapt2 link -I $AJ --manifest AndroidManifest.xml --min-sdk-version 24 --target-sdk-version 34 --version-code 1 --version-name 1.0 -o out/base.apk out/flat/*.flat
javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $AJ:$BT/core-lambda-stubs.jar -d out/cls src/com/khaledtrade/app/*.java
d8 --lib $AJ --min-api 24 --output out/dex out/cls/com/khaledtrade/app/*.class
cp out/base.apk out/unaligned.apk
(cd out/dex && zip -q ../unaligned.apk classes.dex)
zipalign -f -p 4 out/unaligned.apk out/aligned.apk
KS=/downloads/kt/apk/khaled-trade.keystore
if [ ! -f $KS ]; then keytool -genkeypair -keystore $KS -alias kt -keyalg RSA -keysize 2048 -validity 9125 -storepass "$(cat /downloads/kt/apk/.kspass)" -keypass "$(cat /downloads/kt/apk/.kspass)" -dname "CN=Khaled Trade, O=Khaled Trade, C=EG"; fi
apksigner sign --ks $KS --ks-key-alias kt --ks-pass env:KSP --key-pass env:KSP --out out/khaled-trade.apk out/aligned.apk
apksigner verify -v out/khaled-trade.apk | head -6
ls -la out/khaled-trade.apk
